package com.liferay.ide.tests;

import com.liferay.portal.kernel.xmlrpc.Method;
import com.liferay.portal.kernel.xmlrpc.Response;
import com.liferay.portal.kernel.xmlrpc.XmlRpcException;

public class XmlrpcMethodImpl implements Method
{

    @Override
    public Response execute( long arg0 ) throws XmlRpcException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getMethodName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getToken()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean setArguments( Object[] arg0 )
    {
        // TODO Auto-generated method stub
        return false;
    }

}
