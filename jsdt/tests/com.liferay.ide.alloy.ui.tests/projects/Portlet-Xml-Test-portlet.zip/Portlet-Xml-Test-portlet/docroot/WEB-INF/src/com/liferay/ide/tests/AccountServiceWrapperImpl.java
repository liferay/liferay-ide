package com.liferay.ide.tests;

import com.liferay.portal.service.AccountService;
import com.liferay.portal.service.AccountServiceWrapper;

public class AccountServiceWrapperImpl extends AccountServiceWrapper
{

    public AccountServiceWrapperImpl( AccountService accountService )
    {
        super( accountService );
        // TODO Auto-generated constructor stub
    }
}
