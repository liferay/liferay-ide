package com.liferay.ide.tests;
import com.liferay.portal.kernel.pop.MessageListener;
import com.liferay.portal.kernel.pop.MessageListenerException;

import javax.mail.Message;

public class PopMessageListenerImpl implements MessageListener
{

    @Override
    public boolean accept( String arg0, String arg1, Message arg2 )
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void deliver( String arg0, String arg1, Message arg2 ) throws MessageListenerException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public String getId()
    {
        // TODO Auto-generated method stub
        return null;
    }

}
