package testgradleproject.constants;

/**
 * @author andy
 */
public class TestGradleProjectPortletKeys {

	public static final String TestGradleProject = "TestGradleProject";

}