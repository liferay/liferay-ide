create index IX_1965497A on testsb_Foo (field2);
create index IX_DC695A66 on testsb_Foo (uuid_);
create index IX_DA5C4E02 on testsb_Foo (uuid_, companyId);
create unique index IX_D3446D04 on testsb_Foo (uuid_, groupId);