package mavendependencytestproject;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class Mavendependencytestproject implements BundleActivator {

	@Override
	public void start(BundleContext bundleContext) throws Exception {
	}

	@Override
	public void stop(BundleContext bundleContext) throws Exception {
	}

}