module.exports = {
    CSS: 0,
    JS: 1,
    JSP: 2,
    JSPF: 3,
    UNKNOWN: 4
};