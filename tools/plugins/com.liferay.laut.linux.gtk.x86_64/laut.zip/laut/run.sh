#!/usr/bin/env bash

node/bin/node data/bin/laut.js "$@"