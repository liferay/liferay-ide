package com.liferay.ide.tests;


import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.security.permission.PermissionChecker;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portlet.social.model.SocialActivity;
import com.liferay.portlet.social.model.SocialActivityFeedEntry;
import com.liferay.portlet.social.model.SocialActivityInterpreter;
import com.liferay.portlet.social.model.SocialActivitySet;

public class SocialActivityInterpreterImpl implements SocialActivityInterpreter
{

    @Override
    public String[] getClassNames()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getSelector()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean hasPermission( PermissionChecker arg0, SocialActivity arg1, String arg2, ServiceContext arg3 )
        throws Exception
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public SocialActivityFeedEntry interpret( SocialActivity arg0, ServiceContext arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public SocialActivityFeedEntry interpret( SocialActivitySet arg0, ServiceContext arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void updateActivitySet( long arg0 ) throws PortalException
    {
        // TODO Auto-generated method stub
        
    }

}
