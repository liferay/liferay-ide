package com.liferay.ide.tests;


import com.liferay.portal.kernel.portlet.ConfigurationAction;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletConfig;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
public class ConfigurationActionImpl implements ConfigurationAction
{

    @Override
    public void processAction( PortletConfig arg0, ActionRequest arg1, ActionResponse arg2 ) throws Exception
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public String render( PortletConfig arg0, RenderRequest arg1, RenderResponse arg2 ) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

}
