package com.test;

import com.liferay.util.bridges.mvc.MVCPortlet;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

/**
 * Portlet implementation class NewPortlet
 */
public class NewPortlet extends MVCPortlet {

    public void actionTest(ActionRequest actionRequest, ActionResponse actionResponse) {
    }
 

}
