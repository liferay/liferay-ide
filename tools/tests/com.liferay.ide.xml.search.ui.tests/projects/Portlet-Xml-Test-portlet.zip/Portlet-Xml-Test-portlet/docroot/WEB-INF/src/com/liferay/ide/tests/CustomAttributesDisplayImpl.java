package com.liferay.ide.tests;

import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portlet.expando.model.CustomAttributesDisplay;

public class CustomAttributesDisplayImpl implements CustomAttributesDisplay
{

    @Override
    public String getClassName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getIconCssClass()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getIconPath( ThemeDisplay arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getPortletId()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setClassNameId( long arg0 )
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void setPortletId( String arg0 )
    {
        // TODO Auto-generated method stub
        
    }

}
