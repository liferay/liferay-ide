package com.liferay.ide.tests;

import com.liferay.portal.kernel.webdav.Resource;
import com.liferay.portal.kernel.webdav.Status;
import com.liferay.portal.kernel.webdav.WebDAVException;
import com.liferay.portal.kernel.webdav.WebDAVRequest;
import com.liferay.portal.kernel.webdav.WebDAVStorage;
import com.liferay.portal.kernel.webdav.methods.MethodFactory;
import com.liferay.portal.model.Lock;

import java.util.List;


public class WebDAVStorageImpl implements WebDAVStorage
{

    @Override
    public int copyCollectionResource( WebDAVRequest arg0, Resource arg1, String arg2, boolean arg3, long arg4 )
        throws WebDAVException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int copySimpleResource( WebDAVRequest arg0, Resource arg1, String arg2, boolean arg3 )
        throws WebDAVException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int deleteResource( WebDAVRequest arg0 ) throws WebDAVException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public MethodFactory getMethodFactory()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Resource getResource( WebDAVRequest arg0 ) throws WebDAVException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Resource> getResources( WebDAVRequest arg0 ) throws WebDAVException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getRootPath()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getToken()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean isAvailable( WebDAVRequest arg0 ) throws WebDAVException
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isSupportsClassTwo()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public Status lockResource( WebDAVRequest arg0, String arg1, long arg2 ) throws WebDAVException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Status makeCollection( WebDAVRequest arg0 ) throws WebDAVException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int moveCollectionResource( WebDAVRequest arg0, Resource arg1, String arg2, boolean arg3 )
        throws WebDAVException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int moveSimpleResource( WebDAVRequest arg0, Resource arg1, String arg2, boolean arg3 )
        throws WebDAVException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int putResource( WebDAVRequest arg0 ) throws WebDAVException
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public Lock refreshResourceLock( WebDAVRequest arg0, String arg1, long arg2 ) throws WebDAVException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setRootPath( String arg0 )
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void setToken( String arg0 )
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public boolean unlockResource( WebDAVRequest arg0, String arg1 ) throws WebDAVException
    {
        // TODO Auto-generated method stub
        return false;
    }

}
