package com.liferay.ide.tests;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.notifications.UserNotificationFeedEntry;
import com.liferay.portal.kernel.notifications.UserNotificationHandler;
import com.liferay.portal.model.UserNotificationEvent;
import com.liferay.portal.service.ServiceContext;

public class UserNotificationHandlerImpl implements UserNotificationHandler
{

    @Override
    public String getPortletId()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getSelector()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public UserNotificationFeedEntry interpret( UserNotificationEvent arg0, ServiceContext arg1 )
        throws PortalException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean isDeliver( long arg0, long arg1, int arg2, int arg3, ServiceContext arg4 ) throws PortalException
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isOpenDialog()
    {
        // TODO Auto-generated method stub
        return false;
    }

}
