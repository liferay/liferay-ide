package com.liferay.ide.tests;

public class Orphan {

	public void test(){
		get

	}

}
