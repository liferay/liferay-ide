package com.liferay.ide.tests;

import com.liferay.portal.kernel.messaging.MessageListener;

public abstract class MessageListenerImpl implements MessageListener
{

}
