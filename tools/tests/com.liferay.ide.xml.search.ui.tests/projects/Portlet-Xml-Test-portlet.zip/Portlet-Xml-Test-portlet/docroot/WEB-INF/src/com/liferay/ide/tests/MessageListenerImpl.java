
package com.liferay.ide.tests;

import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;

public class MessageListenerImpl implements MessageListener
{

    @Override
    public void receive( Message arg0 ) throws MessageListenerException
    {
        // TODO Auto-generated method stub

    }

    public MessageListenerImpl()
    {
        super();
        // TODO Auto-generated constructor stub
    }
}
