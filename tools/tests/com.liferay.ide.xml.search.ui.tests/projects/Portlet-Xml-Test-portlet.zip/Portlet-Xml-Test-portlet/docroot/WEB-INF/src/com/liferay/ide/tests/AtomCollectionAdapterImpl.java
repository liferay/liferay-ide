package com.liferay.ide.tests;


import com.liferay.portal.kernel.atom.AtomCollectionAdapter;
import com.liferay.portal.kernel.atom.AtomEntryContent;
import com.liferay.portal.kernel.atom.AtomException;
import com.liferay.portal.kernel.atom.AtomRequestContext;

import java.io.InputStream;
import java.util.Date;
import java.util.List;
public class AtomCollectionAdapterImpl implements AtomCollectionAdapter
{

    @Override
    public void deleteEntry( String arg0, AtomRequestContext arg1 ) throws AtomException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public String getCollectionName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object getEntry( String arg0, AtomRequestContext arg1 ) throws AtomException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List getEntryAuthors( Object arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public AtomEntryContent getEntryContent( Object arg0, AtomRequestContext arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getEntryId( Object arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getEntrySummary( Object arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getEntryTitle( Object arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Date getEntryUpdated( Object arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Iterable getFeedEntries( AtomRequestContext arg0 ) throws AtomException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getFeedTitle( AtomRequestContext arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getMediaContentType( Object arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getMediaName( Object arg0 ) throws AtomException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public InputStream getMediaStream( Object arg0 ) throws AtomException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object postEntry( String arg0, String arg1, String arg2, Date arg3, AtomRequestContext arg4 )
        throws AtomException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object postMedia( String arg0, String arg1, InputStream arg2, AtomRequestContext arg3 ) throws AtomException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void putEntry( Object arg0, String arg1, String arg2, String arg3, Date arg4, AtomRequestContext arg5 )
        throws AtomException
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void putMedia( Object arg0, String arg1, String arg2, InputStream arg3, AtomRequestContext arg4 )
        throws AtomException
    {
        // TODO Auto-generated method stub
        
    }

}
