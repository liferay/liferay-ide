package com.liferay.ide.tests;

import javax.portlet.PortletURL;
import javax.portlet.PortletURLGenerationListener;
import javax.portlet.ResourceURL;

public class PortletURLGenerationListenerImpl implements
		PortletURLGenerationListener {

	@Override
	public void filterActionURL(PortletURL arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void filterRenderURL(PortletURL arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void filterResourceURL(ResourceURL arg0) {
		// TODO Auto-generated method stub

	}

}
