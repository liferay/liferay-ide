package com.liferay.ide.tests;

import java.util.Locale;

import javax.portlet.PortletURL;

import com.liferay.portal.kernel.search.BooleanQuery;
import com.liferay.portal.kernel.search.Document;
import com.liferay.portal.kernel.search.IndexerPostProcessor;
import com.liferay.portal.kernel.search.SearchContext;
import com.liferay.portal.kernel.search.Summary;

public class IndexerPostProcessorImpl implements IndexerPostProcessor {

	@Override
	public void postProcessContextQuery(BooleanQuery contextQuery,
			SearchContext searchContext) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void postProcessDocument(Document document, Object obj)
			throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void postProcessFullQuery(BooleanQuery fullQuery,
			SearchContext searchContext) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void postProcessSearchQuery(BooleanQuery searchQuery,
			SearchContext searchContext) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void postProcessSummary(Summary summary, Document document,
			Locale locale, String snippet, PortletURL portletURL) {
		// TODO Auto-generated method stub

	}

}
