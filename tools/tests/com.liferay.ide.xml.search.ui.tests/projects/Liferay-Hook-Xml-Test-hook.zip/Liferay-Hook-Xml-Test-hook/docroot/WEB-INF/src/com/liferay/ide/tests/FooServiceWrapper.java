package com.liferay.ide.tests;

public class FooServiceWrapper implements FooService {

}
