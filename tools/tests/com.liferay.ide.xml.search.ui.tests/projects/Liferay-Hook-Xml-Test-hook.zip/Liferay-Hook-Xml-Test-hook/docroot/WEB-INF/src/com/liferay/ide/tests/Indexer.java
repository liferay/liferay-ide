package com.liferay.ide.tests;

import java.io.Serializable;
import java.util.Map;

import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portlet.expando.model.ExpandoBridge;

public class Indexer implements BaseModel<T> {

	@Override
	public Class<?> getModelClass() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getModelClassName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int compareTo(T o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ExpandoBridge getExpandoBridge() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isCachedModel() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEscapedModel() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNew() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void resetOriginalValues() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setExpandoBridgeAttributes(BaseModel<?> baseModel) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setExpandoBridgeAttributes(ExpandoBridge expandoBridge) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setExpandoBridgeAttributes(ServiceContext serviceContext) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setNew(boolean n) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public CacheModel<T> toCacheModel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T toEscapedModel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T toUnescapedModel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String toXmlString() {
		// TODO Auto-generated method stub
		return null;
	}

}
