package com.liferay.ide.tests;

public interface FooService {

}
