

public interface InterfaceTest
{

}
