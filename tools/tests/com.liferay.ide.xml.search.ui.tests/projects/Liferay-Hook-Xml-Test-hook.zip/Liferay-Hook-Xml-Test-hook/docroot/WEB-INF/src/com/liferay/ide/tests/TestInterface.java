package com.liferay;


public interface TestInterface
{

}
