package com.liferay.ide.tests;

/**
 * for tests, doesn't extend or implement any class or interface
 */
public class Orphan {

}
