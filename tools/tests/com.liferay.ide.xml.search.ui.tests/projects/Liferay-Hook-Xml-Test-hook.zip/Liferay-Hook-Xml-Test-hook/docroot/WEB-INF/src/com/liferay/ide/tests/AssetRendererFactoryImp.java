import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.LiferayPortletRequest;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.kernel.util.Tuple;
import com.liferay.portal.security.permission.PermissionChecker;
import com.liferay.portlet.asset.model.AssetEntry;
import com.liferay.portlet.asset.model.AssetRenderer;
import com.liferay.portlet.asset.model.AssetRendererFactory;
import com.liferay.portlet.asset.model.ClassTypeReader;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.portlet.PortletRequest;
import javax.portlet.PortletURL;
import javax.portlet.WindowState;

public class AssetRendererFactoryImp implements AssetRendererFactory
{

    @Override
    public AssetEntry getAssetEntry( long arg0 ) throws PortalException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public AssetEntry getAssetEntry( String arg0, long arg1 ) throws PortalException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public AssetRenderer getAssetRenderer( long arg0 ) throws PortalException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public AssetRenderer getAssetRenderer( long arg0, int arg1 ) throws PortalException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public AssetRenderer getAssetRenderer( long arg0, String arg1 ) throws PortalException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getClassName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long getClassNameId()
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public Tuple getClassTypeFieldName( long arg0, String arg1, Locale arg2 ) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<Tuple> getClassTypeFieldNames( long arg0, Locale arg1, int arg2, int arg3 ) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int getClassTypeFieldNamesCount( long arg0, Locale arg1 ) throws Exception
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public ClassTypeReader getClassTypeReader()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Map<Long, String> getClassTypes( long[] arg0, Locale arg1 ) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getIconCssClass()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getIconPath( PortletRequest arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getPortletId()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getType()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getTypeName( Locale arg0 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getTypeName( Locale arg0, boolean arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getTypeName( Locale arg0, long arg1 )
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PortletURL getURLAdd( LiferayPortletRequest arg0, LiferayPortletResponse arg1 ) throws PortalException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PortletURL getURLView( LiferayPortletResponse arg0, WindowState arg1 ) throws PortalException
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean hasAddPermission( PermissionChecker arg0, long arg1, long arg2 ) throws Exception
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean hasClassTypeFieldNames( long arg0, Locale arg1 ) throws Exception
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean hasPermission( PermissionChecker arg0, long arg1, String arg2 ) throws Exception
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isActive( long arg0 )
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isCategorizable()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isLinkable()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isListable( long arg0 )
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isSelectable()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isSupportsClassTypes()
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void setClassName( String arg0 )
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void setPortletId( String arg0 )
    {
        // TODO Auto-generated method stub
        
    }

}
