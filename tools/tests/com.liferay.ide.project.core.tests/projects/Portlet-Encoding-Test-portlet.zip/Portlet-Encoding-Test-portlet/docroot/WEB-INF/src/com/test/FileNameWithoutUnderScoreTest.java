package com.test;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class FileNameWithoutUnderScoreTest
 */
public class FileNameWithoutUnderScoreTest extends MVCPortlet {
 

}
