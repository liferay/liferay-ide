package com.test;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class FileNameWithUnderscoreTest2
 */
public class FileNameWithUnderscoreTest2 extends MVCPortlet {
 

}
