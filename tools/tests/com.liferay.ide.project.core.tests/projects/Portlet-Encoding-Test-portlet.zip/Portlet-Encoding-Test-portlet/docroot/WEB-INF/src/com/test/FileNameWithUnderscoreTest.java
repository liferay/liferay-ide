package com.test;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class FileNameWithUnderscoreTest
 */
public class FileNameWithUnderscoreTest extends MVCPortlet {
 

}
