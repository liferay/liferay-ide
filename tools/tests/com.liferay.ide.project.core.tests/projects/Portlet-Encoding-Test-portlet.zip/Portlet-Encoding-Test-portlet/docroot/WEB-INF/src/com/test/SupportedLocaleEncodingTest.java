package com.test;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class SupportedLocaleEncodingTest
 */
public class SupportedLocaleEncodingTest extends MVCPortlet {
 

}
